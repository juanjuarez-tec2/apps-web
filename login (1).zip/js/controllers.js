angular.module('app.controllers', [])
     
.controller('pageCtrl', function($scope) {

})
   
.controller('loginCtrl', function($scope) {

})
   
.controller('signupCtrl', function($scope) {

})
   
.controller('tab2DefaultPageCtrl', function($scope) {

})
 